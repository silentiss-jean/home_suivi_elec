"""Plateforme sensor pour Home Suivi Élec."""
from homeassistant.core import HomeAssistant
from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN

async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up sensors from a config entry."""
    # Récupérer les sensors d'énergie depuis hass.data
    energy_sensors = hass.data.get(DOMAIN, {}).get("energy_sensors", [])
    
    if energy_sensors:
        async_add_entities(energy_sensors, True)
