// js/configuration.state.js — stable (folds) + hydratation référence robuste

console.info("[config.state] module chargé");

const FOLD_KEY = "hse_fold_v1";

function readStore() {
  try {
    const raw = localStorage.getItem(FOLD_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    console.warn("[config.state] readStore error:", e);
    return {};
  }
}

function writeStore(obj) {
  try {
    localStorage.setItem(FOLD_KEY, JSON.stringify(obj || {}));
  } catch (e) {
    console.warn("[config.state] writeStore error:", e);
  }
}

// Folds
export function getFold(integration, columnName) {
  const store = readStore();
  const col = store[columnName] || {};
  return col[integration] === true;
}

export function setFold(integration, columnName, isOpen) {
  const store = readStore();
  store[columnName] ??= {};
  store[columnName][integration] = !!isOpen;
  writeStore(store);
  console.debug("[config.state] setFold:", columnName, integration, !!isOpen);
}

// UI helpers
function _refreshRefUI() {
  const switchEl = document.getElementById("useExternalConfig");
  const active = switchEl?.checked ?? false;
  const choice = document.querySelector("input[name='referenceSourceChoice']:checked")?.value || "sensor";
  const sensorRow = document.getElementById("referenceSensorRow");
  const manualRow = document.getElementById("referenceManualRow");
  if (sensorRow) sensorRow.style.display = active && choice === "sensor" ? "" : "none";
  if (manualRow) manualRow.style.display = active && choice === "manual" ? "" : "none";
}

// Hydratation options
export function hydrateUserConfig(options) {
  console.info("[config.state] hydrateUserConfig", options);

  const setVal = (id, v) => { const el = document.getElementById(id); if (el != null && v != null) el.value = v; };
  const setChk = (id, v) => { const el = document.getElementById(id); if (el != null) el.checked = !!v; };

  // ✅ CORRECTION : Abonnements avec fallbacks
  setVal("abonnementHT", options.abonnementHT ?? options.abonnementht);
  setVal("abonnementTTC", options.abonnementTTC ?? options.abonnementttc);
  
  const typeSel = document.getElementById("typeContrat");
  const hpHCFields = document.getElementById("hpHCFields");
  const blocFixe = document.getElementById("blocFixe");
  
  if (typeSel) {
    typeSel.value = options.typeContrat || "fixe";
    
    // ✅ CRITIQUE : Déclencher l'affichage des blocs après hydratation
    console.log("[config.state] Type contrat détecté:", typeSel.value);
    if (typeSel.value === "fixe") {
      if (blocFixe) {
        blocFixe.style.display = "block";
        console.log("[config.state] Bloc fixe affiché");
      }
      if (hpHCFields) {
        hpHCFields.style.display = "none";
        console.log("[config.state] Bloc HP/HC masqué");
      }
    } else if (typeSel.value === "hp-hc") {
      if (blocFixe) {
        blocFixe.style.display = "none";
        console.log("[config.state] Bloc fixe masqué");
      }
      if (hpHCFields) {
        hpHCFields.style.display = "block";
        console.log("[config.state] Bloc HP/HC affiché");
      }
    }
  }
  
  // ✅ CRITIQUE : Ordre des fallbacks corrigé (prix_ht avec underscore en PREMIER)
  // Pour contrat fixe
  setVal("tarifFixeHT", options.prix_ht ?? options.prixht ?? options.prixHT);
  setVal("tarifFixeTTC", options.prix_ttc ?? options.prixttc ?? options.prixTTC);
  
  // Pour HP/HC
  setVal("tarifHP", options.prix_ht_hp ?? options.prixhthp ?? options.prixHTHP);
  setVal("tarifHC", options.prix_ht_hc ?? options.prixhthc ?? options.prixHTHC);
  setVal("tarifHPTTC", options.prix_ttc_hp ?? options.prixttchp ?? options.prixTTCHP);
  setVal("tarifHCTTC", options.prix_ttc_hc ?? options.prixttchc ?? options.prixTTCHC);
  
  setVal("heuresHPDebut", options.hc_start ?? options.hcstart ?? options.heuresHPDebut);
  setVal("heuresHPFin", options.hc_end ?? options.hcend ?? options.heuresHPFin);

  // Référence
  const hasSensor = !!options.externalCapteur;
  const hasManual = Number(options.consommationExterne) > 0;

  setChk("useExternalConfig", !!options.useExternal);
  const radioSensor = document.querySelector("input[name='referenceSourceChoice'][value='sensor']");
  const radioManual = document.querySelector("input[name='referenceSourceChoice'][value='manual']");
  if (options.useExternal) {
    if (hasSensor && radioSensor) radioSensor.checked = true;
    else if (hasManual && radioManual) radioManual.checked = true;
  }

  setVal("capteurExterneSelectConfig", options.externalCapteur || "");
  setVal("consommationExterneConfig", options.consommationExterne ?? "");

  _refreshRefUI();
}

// Binding général (bouton "saveSelection" si présent)
export function bindUserOptions(onSave) {
  console.info("[config.state] bindUserOptions");
  const btn = document.getElementById("saveSelection");
  if (btn) {
    btn.addEventListener("click", async (ev) => {
      ev?.preventDefault?.();
      
      // ✅ CORRECTION : Utiliser les bons noms de champs (avec underscores)
      const typeContrat = document.getElementById("typeContrat").value;
      const payload = {
        abonnementHT: parseFloat(document.getElementById("abonnementHT")?.value) || 0,
        abonnementTTC: parseFloat(document.getElementById("abonnementTTC")?.value) || 0,
        typeContrat: typeContrat,
        useExternal: document.getElementById("useExternalConfig")?.checked ?? false,
        externalCapteur: document.getElementById("capteurExterneSelectConfig")?.value || "",
        consommationExterne: parseFloat(document.getElementById("consommationExterneConfig")?.value) || 0,
      };
      
      // ✅ Tarifs conditionnels selon type de contrat (avec underscores)
      if (typeContrat === "fixe") {
        payload.prix_ht = parseFloat(document.getElementById("tarifFixeHT")?.value) || 0;
        payload.prix_ttc = parseFloat(document.getElementById("tarifFixeTTC")?.value) || 0;
      } else if (typeContrat === "hp-hc") {
        payload.prix_ht_hp = parseFloat(document.getElementById("tarifHP")?.value) || 0;
        payload.prix_ht_hc = parseFloat(document.getElementById("tarifHC")?.value) || 0;
        payload.prix_ttc_hp = parseFloat(document.getElementById("tarifHPTTC")?.value) || 0;
        payload.prix_ttc_hc = parseFloat(document.getElementById("tarifHCTTC")?.value) || 0;
        payload.hc_start = document.getElementById("heuresHPDebut")?.value || "";
        payload.hc_end = document.getElementById("heuresHPFin")?.value || "";
      }
      
      if (typeof onSave === "function") await onSave(payload);
    });
  }

  // ✅ Toggle d'UI local pour le type de contrat (event listener sur le select)
  const typeContratSelect = document.getElementById("typeContrat");
  const blocFixe = document.getElementById("blocFixe");
  const hpHCFields = document.getElementById("hpHCFields");
  
  if (typeContratSelect) {
    typeContratSelect.addEventListener("change", () => {
      const val = typeContratSelect.value;
      console.log("[config.state] Changement de contrat:", val);
      if (val === "fixe") {
        if (blocFixe) blocFixe.style.display = "block";
        if (hpHCFields) hpHCFields.style.display = "none";
      } else if (val === "hp-hc") {
        if (blocFixe) blocFixe.style.display = "none";
        if (hpHCFields) hpHCFields.style.display = "block";
      }
    });
  }

  // Toggle d'UI local pour la section référence
  const switchEl = document.getElementById("useExternalConfig");
  const sourceRadios = document.querySelectorAll("input[name='referenceSourceChoice']");
  if (switchEl) switchEl.addEventListener("change", _refreshRefUI);
  sourceRadios.forEach(r => r.addEventListener("change", _refreshRefUI));
  _refreshRefUI();
}
